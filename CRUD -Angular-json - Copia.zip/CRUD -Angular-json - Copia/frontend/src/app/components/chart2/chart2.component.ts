import { Component, ElementRef, OnInit, ViewChild } from '@angular/core';
declare var google: any;

@Component({
  selector: 'app-chart2',
  templateUrl: './chart2.component.html',
  styleUrls: ['./chart2.component.scss']
})
export class Chart2Component implements OnInit {

  @ViewChild('lineChart') lineChart!: ElementRef;

  drawChart = () => {
    const data = google.visualization.arrayToDataTable([
      ['Item', 'ICVA Nominal', 'ICVA Deflacionado', 'ICVA Nominal', 'ICVA Deflacionado'],
      ['Jan',  -10, 40, 11, 20],
      ['Fev',  17,6,16,22],
      ['Mar',  21,32,41,10],
      ['Abr',  10,30,5,40]
    ]);

    const options = {
      title: 'Título do Chart',
      legend: { position: 'bottom' },
      tooltip: { isHtml: true },
      colors: [
        '#0080ff', '#778899', '#32CD32', '#FF8C00'
      ],
      // Gives each series an axis that matches the vAxes number below.
      series: {
        0: {targetAxisIndex: 0},
        // 1: {targetAxisIndex: 1}
      },
      vAxes: {
        // Adds titles to each axis.
        0: {title: '%'},
        // 1: {title: 'Daylight'}
      },
      // vAxis: {
      //   viewWindow: {
      //     max: 30
      //   }
      // }
    };

    const chart = new google.visualization.LineChart(this.lineChart.nativeElement);
    chart.draw(data, options);
  }

  constructor() { }

  ngOnInit(): void {

  }

  ngAfterViewInit(): void {
    google.charts.load('current', {packages: ['corechart', 'line']});
    google.charts.setOnLoadCallback(this.drawChart);
  }

}
