import { Component, OnInit } from '@angular/core';
import { Chart, registerables } from 'chart.js';

@Component({
  selector: 'app-chart3',
  templateUrl: './chart3.component.html',
  styleUrls: ['./chart3.component.scss']
})
export class Chart3Component implements OnInit {

  chart: any;
  chart2: any;

  constructor() { }

  ngOnInit() {
    this.chart = document.getElementById('my_first_chart');
    this.chart2 = document.getElementById('my_first_chart2');

    Chart.register(...registerables);
    this.loadChart();
    this.loadChart2();
  }

  loadChart(): void{
    var mychart = new Chart(this.chart,{
      type: 'line',
      data: {
        datasets: [
          {
            data: [30, 60, 40, 50, 40, 55, 85, 65, 75, 50, 70],
            label: 'Seria 1',
            backgroundColor: '#007bff',
            borderColor: '#007bff',
            tension: 0.2, //faz linhas mais curvadas
          },
          {
            data: [20, 40, 10, 30, 50, 55, 65, 75, 85, 90, 95],
            label: 'Seria 2',
            backgroundColor: '#FF4500',
            borderColor: '#FF4500',
            tension: 0.2, //faz linhas mais curvadas
          },
          {
            data: [-1, 6, 7, 10, 12, 15, 22, 27, 28.5, 29.9, 33],
            label: 'Seria 3',
            backgroundColor: '#007bff',
            borderColor: '#007bff',
            tension: 0.2, //faz linhas mais curvadas
          },
          {
            data: [10, 11, 14, 17, 19, 22, 25, 27, 30, 31, 33],
            label: 'Seria 4',
            backgroundColor: '#FF4500',
            borderColor: '#FF4500',
            tension: 0.2, //faz linhas mais curvadas
          }
        ],
        labels: ['Jan', 'Fev', 'Mar', 'Abr', 'Mai', 'Jun', 'Jul', 'Ago', 'Set',]
      },
      options: {
        responsive: true,
        maintainAspectRatio: false,
        interaction: {
          intersect: true,
          mode: 'index',
          axis: 'xy'
        },
        scales: {
          y: {
            beginAtZero: true,
            display: true,
          }
        },
        plugins: {
          tooltip: {
            callbacks: {
              label: function(tooltipItem) {
                var label: any = mychart.data.datasets[tooltipItem.datasetIndex].label;
                var value: any = mychart.data.datasets[tooltipItem.datasetIndex].data[tooltipItem.dataIndex];
                return label + ' - ' + value +'%';
              }
            },
            position: 'nearest'
          }
        }
      }
    })
  }

  loadChart2(): void{
    var mychart2 =new Chart(this.chart2,{
      type: 'line',
      data: {
        datasets: [{
          data: [20, 50, 100, 75, 25, 0],
          label: 'Left dataset',

          // This binds the dataset to the left y axis
          yAxisID: 'left-y-axis'
      }, {
          data: [0.1, 0.5, 1.0, 2.0, 1.5, 0],
          label: 'Right dataset',

          // This binds the dataset to the right y axis
          yAxisID: 'right-y-axis'
      }],
      labels: ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun']
        // datasets: [
        //   {
        //     data: [{x:'Jan', y:10}, {x:'Fev', y:12}, {x:'Mar', y:12.7}, {x:'Abr', y:14}, {x:'Mai', y:15}, {x:'Jun', y:17}],
        //     label: 'ICVA Nominal',
        //     backgroundColor: '#017CEB',
        //     borderColor: '#017CEB',
        //     //pointRadius: 5
        //   },
        //   {
        //     data: [{x:'Jan', y:5}, {x:'Fev', y:7}, {x:'Mar', y:8.7}, {x:'Abr', y:10}, {x:'Mai', y:10.5}, {x:'Jun', y:12}],
        //     label: 'ICVA Deflacionado',
        //     backgroundColor: '#8A99A8',
        //     borderColor: '#8A99A8',
        //   },
        //   {
        //     data: [{x:'Jan', y:-5}, {x:'Fev', y:2}, {x:'Mar', y:2.7}, {x:'Abr', y:4}, {x:'Mai', y:7}, {x:'Jun', y:10}],
        //     label: 'ICVA Nominal',
        //     backgroundColor: '#26A69A',
        //     borderColor: '#26A69A',
        //   },
        //   {
        //     data: [{x:'Jan', y:-1}, {x:'Fev', y:2.7}, {x:'Mar', y:4.7}, {x:'Abr', y:6}, {x:'Mai', y:10}, {x:'Jun', y:11}],
        //     label: 'ICVA Deflacionado',
        //     backgroundColor: '#FA9297',
        //     borderColor: '#FA9297',
        //   }
        // ],
      },
      options: {
        responsive: true,
        maintainAspectRatio: false,
        interaction: {
          mode: 'index'
        },
        events: ['click'], //tooltip aparece com o click
        layout: {
          padding: {
              left: 50,
              right: 50
          }
        },
        plugins: {
          legend: {
            display: true,
            position: 'bottom',
            onClick: this.teste,
            labels: {
              // This more specific font property overrides the global property
              font: {
                  size: 14
              }
            }
          },
          tooltip: {
            position: 'nearest',
            bodyColor: 'green', //cor do texto
            //boxWidth: 450, // largura do tooltip
            //boxHeight: 200,
            //usePointStyle: true,
                // callbacks: {
                //     labelPointStyle: function(context) {
                //         return {
                //             pointStyle: 'triangle',
                //             rotation: 10
                //         };
                //     }
                // },
            //callbacks: {
              // label: function(context) { //função para colocar valor como moeda no tooltip
              //     var label = context.dataset.label || '';

              //     if (label) {
              //         label += ': ';
              //     }
              //     if (context.parsed.y !== null) {
              //         label += new Intl.NumberFormat('pt-BR', { style: 'currency', currency: 'BRL' }).format(context.parsed.y);
              //     }
              //     return label;
              // }
              // labelColor: function(context) {
              //   return {
              //       borderColor: 'green',
              //       backgroundColor: 'rgb(255, 144, 132)',
              //       borderWidth: 2,
              //       borderDash: [2, 2],
              //       borderRadius: 2,
              //   };
              // },
              // labelTextColor: function(context) {
              //   return '#ffffff';
              // }
            //}
          }
        },
        scales: {
          'left-y-axis': {
              type: 'linear',
              position: 'left'
          },
          'right-y-axis': {
              type: 'linear',
              position: 'right'
          }
      },
        // scales: {
        //   y: {
        //     beginAtZero: true,
        //     display: true,
        //   },
        //   x: {
        //     title: {
        //       color: 'red',
        //       display: true,
        //       text: '2020'
        //     }
        //   }
        // },
        elements: {
          point: {
            backgroundColor: '#ffffff',
            borderColor: '#000000',
            borderWidth: 2,
            radius: 5, // tamanho da bolinha
            hoverRadius: 5
          }
        },
      }
    })
  }

 teste = function(){
    alert("deu certo!!!")
  }

  triggerTooltip = function(chart: { tooltip: any; chartArea: any; update: () => void; }) {
    const tooltip = chart.tooltip;
    if (tooltip.getActiveElements().length > 0) {
      tooltip.setActiveElements([], {x: 0, y: 0});
    } else {
      const chartArea = chart.chartArea;
      tooltip.setActiveElements([
        {
          datasetIndex: 0,
          index: 2,
        }, {
          datasetIndex: 1,
          index: 2,
        }
      ],
      {
        x: (chartArea.left + chartArea.right) / 2,
        y: (chartArea.top + chartArea.bottom) / 2,
      });
    }

    chart.update();
  }


}
