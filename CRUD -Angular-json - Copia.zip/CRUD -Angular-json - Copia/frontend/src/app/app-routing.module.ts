import { LoginComponent } from './components/login/login.component';
import { ChartComponent } from './components/chart/chart.component';
import { ProductDeleteComponent } from './components/product/product-delete/product-delete.component';
import { ProductUpdateComponent } from './components/product/product-update/product-update.component';
import { ProductCrudComponent } from './views/product-crud/product-crud.component';
import { HomeComponent } from './views/home/home.component';
import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { ProductCreateComponent } from './components/product/product-create/product-create.component';
import { Chart2Component } from './components/chart2/chart2.component';
import { Chart3Component } from './components/chart3/chart3.component';

const routes: Routes = [
  // {
  //   path: "", component: LoginComponent
  // },
  {
    path: "", component: HomeComponent
  },
  {
    path: "products", component: ProductCrudComponent
  },
  {
    path: "products/create", component: ProductCreateComponent
  },
  {
    path: "products/update/:id", component: ProductUpdateComponent
  },
  {
    path: "products/delete/:id", component: ProductDeleteComponent
  },
  {
    path: "chart", component: ChartComponent
  },
  {
    path: "chart2", component: Chart2Component
  },
  {
    path: "chart3", component: Chart3Component
  }
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
